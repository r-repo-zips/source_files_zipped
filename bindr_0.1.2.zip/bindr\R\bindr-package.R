#' @details
#' See [create_env()] for creating an environment populated with active bindings,
#' and [populate_env()] for populating an existing environment.
"_PACKAGE"
