##' @importFrom Rcpp evalCpp
##' @importFrom stats setNames
##' @importFrom utils type.convert
##' @useDynLib reshape2
NULL
