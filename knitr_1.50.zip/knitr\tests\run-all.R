library(testit)
test_pkg("knitr")
