#' @keywords internal
#' @import rlang
#' @importFrom glue glue
"_PACKAGE"

## usethis namespace: start
## usethis namespace: end
NULL
