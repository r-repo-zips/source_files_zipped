globalVariables(c("hue", "value", "chroma", "name",
  "x", "y", "text.colour", "colour"))