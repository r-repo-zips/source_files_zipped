# rendering table wraps in SELECT *

    Code
      out %>% sql_render()
    Output
      <SQL> SELECT *
      FROM `test-sql-build`

