#' @keywords internal
#' @aliases gtable-package
"_PACKAGE"

## usethis namespace: start
#' @import grid
#' @import rlang
#' @importFrom glue glue
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
