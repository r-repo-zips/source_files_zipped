Shiny Dashboard
===============

<!-- badges: start -->
  [![R-CMD-check](https://github.com/rstudio/shinydashboard/actions/workflows/R-CMD-check.yaml/badge.svg)](https://github.com/rstudio/shinydashboard/actions)
<!-- badges: end -->

## Installation

To install from CRAN:

```R
install.packages("shinydashboard")
```

See the documentation at http://rstudio.github.io/shinydashboard/
