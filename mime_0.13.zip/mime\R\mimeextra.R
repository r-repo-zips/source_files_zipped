mimeextra = c(
jsonp = "application/javascript",
r = "text/plain",
rd = "text/plain",
rmd = "text/x-markdown",
rnw = "text/x-sweave",
rproj = "text/rstudio",
scss = "text/css"
)
