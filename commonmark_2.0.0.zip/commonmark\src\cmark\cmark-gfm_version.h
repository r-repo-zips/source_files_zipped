#ifndef CMARK_GFM_VERSION_H
#define CMARK_GFM_VERSION_H

#define CMARK_GFM_VERSION ((0 << 24) | (29 << 16) | (0 << 8) | 6)
#define CMARK_GFM_VERSION_STRING "0.29.0.gfm.6"

#endif
