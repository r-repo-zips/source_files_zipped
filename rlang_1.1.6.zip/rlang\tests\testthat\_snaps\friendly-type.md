# obj_type_friendly() handles NULL

    Code
      friendly_types(NULL)
    Condition <rlang_error>
      Error in `vec_type_friendly()`:
      ! `x` must be a vector.

