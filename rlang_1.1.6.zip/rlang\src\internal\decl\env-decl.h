static
r_obj* env_get_sym(r_obj* env,
                   r_obj* sym,
                   bool inherit,
                   r_obj* last,
                   r_obj* closure_env);
