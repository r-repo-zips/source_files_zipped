library(testthat)
library(htmltools)

test_check("htmltools")
