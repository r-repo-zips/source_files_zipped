#' @keywords internal
"_PACKAGE"

# The following block is used by usethis to automatically manage
# roxygen namespace tags. Modify with care!
## usethis namespace: start
#' @importFrom lifecycle deprecate_soft
#' @importFrom lifecycle deprecated
## usethis namespace: end
#' @import vctrs
#' @import rlang
NULL

# Used for generating transformation function expressions
globalVariables("x")
