# A scope where we can put mutable global variables
.globals <- new.env(parent = emptyenv())
