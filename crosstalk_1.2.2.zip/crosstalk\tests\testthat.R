library(testthat)
library(crosstalk)

test_check("crosstalk")
