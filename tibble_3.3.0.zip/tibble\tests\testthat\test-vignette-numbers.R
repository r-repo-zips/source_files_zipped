test_that("numbers vignette", {
  skip_if_not_installed("dplyr")

  test_galley("numbers")
})
