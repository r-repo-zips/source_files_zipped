R_xlen_t R_calc_serialized_size(SEXP robj);

