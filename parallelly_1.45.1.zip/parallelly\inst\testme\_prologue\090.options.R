## Default options
oopts <- options(
  warn = 1L,
  mc.cores = 2L,
  parallelly.slurm_expand_nodelist.manual = TRUE,
  parallelly.debug = TRUE
)
