

str_block <- function(content) {
  list(
    t = "Str",
    c = as.character(content)
  )
}

