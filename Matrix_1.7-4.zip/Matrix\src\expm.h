#ifndef MATRIX_EXPM_H
#define MATRIX_EXPM_H

#include <Rinternals.h>

SEXP dgeMatrix_expm(SEXP);

#endif /* MATRIX_EXPM_H */
