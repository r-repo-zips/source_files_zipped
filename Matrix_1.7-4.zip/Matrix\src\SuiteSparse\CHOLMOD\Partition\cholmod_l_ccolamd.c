//------------------------------------------------------------------------------
// CHOLMOD/Partition/cholmod_l_ccolamd.c: int64_t version of cholmod_ccolamd
//------------------------------------------------------------------------------

// CHOLMOD/Partition Module.  Copyright (C) 2005-2023, University of Florida.
// All Rights Reserved.  Author: Timothy A. Davis.
// SPDX-License-Identifier: LGPL-2.1+

//------------------------------------------------------------------------------

#define CHOLMOD_INT64
#include "cholmod_ccolamd.c"

