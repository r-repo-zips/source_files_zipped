#' @keywords internal
"_PACKAGE"

#' Using Packages with rsconnect
#'
#' See ?[appDependencies()]
#' @keywords internal
#' @name rsconnectPackages
NULL

#' HTTP Proxy Configuration
#'
#' Please see `vignette("custom-http")`.
#'
#' @keywords internal
#' @name rsconnectProxies
NULL

## usethis namespace: start
#' @import rlang
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
