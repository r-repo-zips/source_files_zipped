# Stub ui.R
#
# Its presence (along with server.R) indicates that this directory contains a
# Shiny application.
