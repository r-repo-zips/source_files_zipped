# Deploying a Quarto project without Quarto is an error

    Code
      makeManifest(appDir)
    Condition
      Error in `quartoInspect()`:
      ! `quarto` not found.
      i Check that it is installed and available on your `PATH`.

