library(testthat)
library(jquerylib)

test_check("jquerylib")
