#ifndef SOURCETOOLS_TOKENIZATION_TOKENIZATION_H
#define SOURCETOOLS_TOKENIZATION_TOKENIZATION_H

#include <sourcetools/tokenization/Registration.h>
#include <sourcetools/tokenization/Token.h>
#include <sourcetools/tokenization/Tokenizer.h>

#endif /* SOURCETOOLS_TOKENIZATION_TOKENIZATION_H */
