
shape_broadcast_ <- function(x, to, x_arg = "x", to_arg = "to") {
  shape_broadcast(x, to, x_arg = x_arg, to_arg = to_arg)
}
