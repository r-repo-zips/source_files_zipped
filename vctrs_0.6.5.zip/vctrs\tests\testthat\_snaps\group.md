# print method is useful

    Code
      x
    Output
      <vctrs_group_rle[3][n = 2]>
      [1] 1x3 2x2 1x1

