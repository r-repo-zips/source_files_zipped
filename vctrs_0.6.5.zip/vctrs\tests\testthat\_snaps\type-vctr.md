# na.fail() works

    Code
      na.fail(x)
    Condition
      Error in `na.fail()`:
      ! missing values in object

# default print and str methods are useful

    Code
      h
    Output
      <hidden[4]>
      [1] xxx xxx xxx xxx

---

    Code
      h[0]
    Output
      <hidden[0]>

---

    Code
      str(h)
    Output
       hidden [1:4] xxx, xxx, xxx, xxx

# default print method shows names

    Code
      h
    Output
      <hidden[3]>
        A   B   C 
      xxx xxx xxx 

