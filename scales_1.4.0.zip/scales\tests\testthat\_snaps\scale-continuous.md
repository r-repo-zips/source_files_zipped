# train_continuous stops on discrete values

    Code
      train_continuous(LETTERS[1:5])
    Condition
      Error:
      ! Discrete value supplied to a continuous scale.
      i Example values: "A" and "E".

