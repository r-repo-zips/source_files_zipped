#' @importFrom fastmap key_missing
#' @export
fastmap::key_missing

#' @importFrom fastmap is.key_missing
#' @export
fastmap::is.key_missing


