# bayesrules (development version)

## bug fixes
- Beta mode calculation has been fixed in `summarize_beta()` and `summarize_beta_binomial()` function for situations when alpha < 1 and/or beta < 1.
