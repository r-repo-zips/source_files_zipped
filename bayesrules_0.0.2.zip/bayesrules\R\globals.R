utils::globalVariables(c("proportion", "classification", ".", ".folds",
                         "x", "y1", "y2", "mu",
                         "likelihood", "f_lambda", "post_median",
                         "post_mean", "post_mad", "post_sd",
                         "center", "error", "l_inner", "u_inner",
                         "l_outer", "u_outer",
                         "error_scaled", "within_inner", "within_outer"))
