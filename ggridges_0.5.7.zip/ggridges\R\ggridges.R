#' Ridgeline plots with ggplot2
#'
#' Please see the package vignettes for usage instructions. For a quick start,
#' check out the examples for [`geom_density_ridges()`].
#'
#' @import ggplot2
#' @keywords internal
"_PACKAGE"

