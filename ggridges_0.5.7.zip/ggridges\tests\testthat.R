library(testthat)
library(ggridges)

test_check("ggridges")
