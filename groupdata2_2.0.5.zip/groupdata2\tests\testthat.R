library(testthat)
library(groupdata2)

if (require("xpectr")) {
  test_check("groupdata2")
}
