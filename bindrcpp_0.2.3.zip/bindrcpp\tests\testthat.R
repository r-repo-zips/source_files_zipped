library(testthat)
library(bindrcpp)

test_check("bindrcpp")
