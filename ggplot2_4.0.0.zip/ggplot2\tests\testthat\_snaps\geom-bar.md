# geom_bar removes bars with parts outside the plot limits

    Removed 1 row containing missing values or values outside the scale range (`geom_bar()`).

