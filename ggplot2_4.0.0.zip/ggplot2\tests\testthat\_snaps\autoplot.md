# autoplot throws helpful error on default

    Objects of class <integer> are not supported by autoplot.
    i Have you loaded the required package?

