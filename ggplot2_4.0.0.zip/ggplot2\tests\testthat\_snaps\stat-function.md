# Warn when drawing multiple copies of the same function

    Multiple drawing groups in `geom_function()`
    i Did you use the correct group, colour, or fill aesthetics?

