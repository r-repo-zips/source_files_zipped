# geom_boxplot for continuous x gives warning if more than one x (#992)

    Continuous x aesthetic
    i did you forget `aes(group = ...)`?

---

    Continuous x aesthetic
    i did you forget `aes(group = ...)`?

---

    Continuous x aesthetic
    i did you forget `aes(group = ...)`?

# boxplots with a group size >1 error

    Can only draw one boxplot per group.
    i Did you forget `aes(group = ...)`?

