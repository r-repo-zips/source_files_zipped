# colorsteps and bins checks the breaks format

    Breaks are not formatted correctly for a bin legend.
    i Use `(<lower>, <upper>]` format to indicate bins.

---

    Breaks are not formatted correctly for a bin legend.
    i Use `(<lower>, <upper>]` format to indicate bins.

# guide_colourbar warns about discrete scales

    `guide_colourbar()` needs continuous scales.

