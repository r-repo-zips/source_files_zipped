
# Markdown tests

This should be discovered. 

![My picture](empty.png)

This should, doo.

<img src="empty.jpg">

But not this, since this file is plain Markdown.

```{r, echo=FALSE}
read.csv(file = "empty.csv")
```

