# errors cleanly on non-vectors

    Code
      desc(mean)
    Condition
      Error in `desc()`:
      ! `x` must be a vector, not a function.

