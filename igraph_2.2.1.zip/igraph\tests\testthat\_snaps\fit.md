# fit_power_law() errors well

    Code
      fit_power_law(1, implementation = "R.mle")
    Condition
      Error in `power.law.fit.old()`:
      ! `x` must be a vector of length at least 2, not 1.

