# validates its inputs

    Code
      complete(mtcars, explicit = 1)
    Condition
      Error in `complete()`:
      ! `explicit` must be `TRUE` or `FALSE`, not the number 1.

