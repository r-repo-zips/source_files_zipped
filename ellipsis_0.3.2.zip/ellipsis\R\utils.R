
paste_line <- function(...) {
  paste(c(...), collapse = "\n")
}
