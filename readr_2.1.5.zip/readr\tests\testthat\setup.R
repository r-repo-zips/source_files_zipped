pre_test_options <- options(
  readr.show_progress = FALSE,
  readr.show_col_types = FALSE
)
