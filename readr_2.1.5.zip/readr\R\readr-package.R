#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom hms hms
#' @importFrom lifecycle deprecate_soft
#' @importFrom lifecycle deprecate_warn
#' @importFrom lifecycle deprecated
#' @importFrom lifecycle is_present
#' @importFrom R6 R6Class
## usethis namespace: end
NULL
