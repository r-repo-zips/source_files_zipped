# augment.glmRob errors informatively

    Code
      augment(x)
    Condition
      Error in `augment()`:
      ! `augment.glmRob()` has been deprecated as the robust package doesn't provide the functionality necessary to implement an augment method.
      i Please see the augment method for <glmrob> objects from robustbase.

