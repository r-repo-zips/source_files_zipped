# tidy.mjoint

    Code
      tidy(mjoint_fit, boot_se = "cat")
    Condition
      Error in `tidy()`:
      ! `boot_se` must be a <bootSE> object.

# augment.mjoint

    Code
      augment(mjoint_fit, data = NULL)
    Condition
      Error in `augment()`:
      ! `data` argument is `NULL`.
      i Try specifying `data` manually.

