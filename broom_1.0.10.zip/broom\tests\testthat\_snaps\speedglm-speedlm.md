# augment.speedlm

    Code
      augment(fit3)
    Condition
      Error in `augment()`:
      ! Must specify `data` argument or refit with `fitted = TRUE`.

