# not all lists can be tidied

    Code
      tidy(nl)
    Condition
      Error in `tidy()`:
      ! No `tidy()` method recognized for this list.

---

    Code
      glance(nl)
    Condition
      Error in `glance()`:
      ! No `glance()` method recognized for this list.

