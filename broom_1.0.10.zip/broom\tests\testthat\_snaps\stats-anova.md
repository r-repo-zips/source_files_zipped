# tidy.anova

    Code
      .res <- tidy(loess_anova)
    Condition
      Warning:
      The column name ENP in ANOVA output was not recognized or transformed.

