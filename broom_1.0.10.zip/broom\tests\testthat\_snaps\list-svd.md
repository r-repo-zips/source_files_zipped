# tidy_svd errors informatively

    Code
      tidy_svd(matrix = c("u", "v"))
    Condition
      Error in `tidy_svd()`:
      ! Must specify a single matrix to tidy.

