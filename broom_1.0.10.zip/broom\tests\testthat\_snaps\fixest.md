# all other fixest estimators run

    Code
      augment(res_fenegbin)
    Condition
      Error in `augment()`:
      ! augment is only supported for fixest models estimated with `feols()`, `feglm()`, or `femlm()`.
      i Supplied model used `fenegbin()`.

---

    Code
      augment(res_fenegbin, df)
    Condition
      Error in `augment()`:
      ! augment is only supported for fixest models estimated with `feols()`, `feglm()`, or `femlm()`.
      i Supplied model used `fenegbin()`.

---

    Code
      augment(res_feNmlm, df)
    Condition
      Error in `augment()`:
      ! augment is only supported for fixest models estimated with `feols()`, `feglm()`, or `femlm()`.
      i Supplied model used `feNmlm()`.

---

    Code
      augment(res_fepois, df)
    Condition
      Error in `augment()`:
      ! augment is only supported for fixest models estimated with `feols()`, `feglm()`, or `femlm()`.
      i Supplied model used `fepois()`.

