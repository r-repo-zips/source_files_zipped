# augment.drc

    Code
      augment(mod)
    Condition
      Error in `augment()`:
      ! Must specify either `data` or `newdata` argument.

---

    Code
      augment(mod2)
    Condition
      Error in `augment()`:
      ! Must specify either `data` or `newdata` argument.

