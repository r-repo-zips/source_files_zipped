
textfile <- function(description, open = "wt") {
  file(description, open = open, encoding = "native.enc")
}
