# splice is deprecated

    Code
      . <- splice()
    Condition
      Warning:
      `splice()` was deprecated in purrr 1.0.0.
      i Please use `list_flatten()` instead.

