library(testthat)
library(purrr)

test_check("purrr")
