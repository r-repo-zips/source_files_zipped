# insistently() resets rate state

    Request failed after 0 attempts.

---

    Request failed after 0 attempts.

# validates inputs

    Code
      insistently(mean, 10)
    Condition
      Error in `insistently()`:
      ! `rate` must be a rate object, not a number.

