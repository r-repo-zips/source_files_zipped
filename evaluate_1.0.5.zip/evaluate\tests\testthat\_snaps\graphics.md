# checks its input

    Code
      trim_intermediate_plots(1)
    Condition
      Error in `trim_intermediate_plots()`:
      ! `x` must be an evaluation object.

