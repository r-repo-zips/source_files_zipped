#!/bin/sh

rm -fr nlopt-src nlopt-build
