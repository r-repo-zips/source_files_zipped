# print.cli_rule

    Code
      rule("foo")
    Output
      -- foo -------------

