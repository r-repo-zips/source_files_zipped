#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @import fs
#' @import rlang
#' @importFrom glue glue
#' @importFrom glue glue_collapse
#' @importFrom lifecycle deprecated
## usethis namespace: end
NULL
