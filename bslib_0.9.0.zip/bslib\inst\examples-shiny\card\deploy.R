rsconnect::deployApp(
  rprojroot::find_package_root_file("inst/examples-shiny/card"),
  appName = "card",
  account = "bslib",
  forceUpdate = TRUE
)
