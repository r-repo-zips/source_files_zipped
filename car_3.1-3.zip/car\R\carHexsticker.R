carHexsticker <- function(){
  browseURL(paste0("file://", system.file("misc", "car-hex.pdf", package="car")))
}